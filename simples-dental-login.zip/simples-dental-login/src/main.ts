import { env } from './config/env';
import { logger } from './infrastructure/logging/Logger';
import { BrowserFactory } from './infrastructure/browser/BrowserFactory';
import { SimplesDentalAuthRepository } from './infrastructure/auth/SimplesDentalAuthRepository';
import { LoginUseCase } from './application/use-cases/LoginUseCase';

/**
 * Composition root: aqui e onde as camadas sao "conectadas".
 * O dominio e a aplicacao nao sabem que estao usando Playwright;
 * apenas essa funcao sabe disso.
 */
async function main(): Promise<void> {
  const browserFactory = new BrowserFactory();

  try {
    const context = await browserFactory.launch();
    const authRepository = new SimplesDentalAuthRepository(context);
    const loginUseCase = new LoginUseCase(authRepository);

    const result = await loginUseCase.execute(
      env.simplesDental.username,
      env.simplesDental.password,
    );

    if (result.success) {
      logger.info(`✔ ${result.message}`);
      process.exitCode = 0;
    } else {
      logger.error(`✘ Falha no login: ${result.message}`);
      process.exitCode = 1;
    }
  } catch (error) {
    logger.error('Erro fatal na execucao do login.', { error });
    process.exitCode = 1;
  } finally {
    await browserFactory.close();
  }
}

main();
