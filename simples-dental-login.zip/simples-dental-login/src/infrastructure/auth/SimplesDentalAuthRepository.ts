import { BrowserContext, Page } from 'playwright';
import { IAuthRepository } from '../../domain/repositories/IAuthRepository';
import { Credentials } from '../../domain/entities/Credentials';
import { LoginResult } from '../../domain/entities/LoginResult';
import { env } from '../../config/env';
import { logger } from '../logging/Logger';
import { AuthenticationError } from '../../shared/errors/AuthenticationError';
import fs from 'fs';
import path from 'path';

/**
 * Seletores da tela de login do Simples Dental.
 *
 * IMPORTANTE: o Simples Dental e uma SPA (o HTML e renderizado via JavaScript),
 * entao os seletores abaixo sao "melhores palpites" baseados em padroes comuns
 * de formularios de login. Antes de rodar em producao, confirme/ajuste os
 * seletores reais gravando um fluxo com:
 *
 *   npx playwright codegen https://app.simplesdental.com/
 *
 * e substitua os valores abaixo pelos seletores reais encontrados.
 */
const SELECTORS = {
  usernameInput: [
    'input[name="username"]',
    'input[name="email"]',
    'input[type="email"]',
    'input[id*="user" i]',
    'input[placeholder*="usu" i]',
    'input[placeholder*="e-mail" i]',
  ],
  passwordInput: [
    'input[name="password"]',
    'input[type="password"]',
    'input[id*="senha" i]',
    'input[placeholder*="senha" i]',
  ],
  submitButton: [
    'button[type="submit"]',
    'button:has-text("Entrar")',
    'button:has-text("Login")',
    'text=Entrar',
  ],
  // Elemento que so existe apos login bem-sucedido (ex: menu principal, avatar do usuario).
  // Ajuste para um seletor confiavel do dashboard do Simples Dental.
  loggedInIndicator: [
    '[data-testid="dashboard"]',
    'text=Agenda',
    'nav',
  ],
  // Mensagem de erro exibida quando as credenciais estao incorretas.
  errorMessage: [
    'text=usuário ou senha inválid',
    'text=credenciais inválidas',
    '[role="alert"]',
    '.error, .alert-danger',
  ],
};

async function firstVisible(page: Page, selectors: string[], timeoutMs: number) {
  for (const selector of selectors) {
    try {
      const locator = page.locator(selector).first();
      await locator.waitFor({ state: 'visible', timeout: timeoutMs });
      return locator;
    } catch {
      // tenta o proximo seletor da lista
    }
  }
  return null;
}

export class SimplesDentalAuthRepository implements IAuthRepository {
  constructor(private readonly context: BrowserContext) {}

  async login(credentials: Credentials): Promise<LoginResult> {
    const page = await this.context.newPage();

    try {
      logger.info(`Navegando para a tela de login: ${env.simplesDental.loginUrl}`);
      await page.goto(env.simplesDental.loginUrl, { waitUntil: 'domcontentloaded' });

      const usernameField = await firstVisible(page, SELECTORS.usernameInput, env.browser.timeoutMs);
      if (!usernameField) {
        throw new AuthenticationError(
          'Nao foi possivel localizar o campo de usuario/e-mail na tela de login. Ajuste SELECTORS.usernameInput em SimplesDentalAuthRepository.ts.',
        );
      }
      await usernameField.fill(credentials.username);
      logger.info('Campo de usuario preenchido.');

      const passwordField = await firstVisible(page, SELECTORS.passwordInput, env.browser.timeoutMs);
      if (!passwordField) {
        throw new AuthenticationError(
          'Nao foi possivel localizar o campo de senha na tela de login. Ajuste SELECTORS.passwordInput em SimplesDentalAuthRepository.ts.',
        );
      }
      await passwordField.fill(credentials.password);
      logger.info('Campo de senha preenchido.');

      const submitButton = await firstVisible(page, SELECTORS.submitButton, env.browser.timeoutMs);
      if (!submitButton) {
        throw new AuthenticationError(
          'Nao foi possivel localizar o botao de submit da tela de login. Ajuste SELECTORS.submitButton em SimplesDentalAuthRepository.ts.',
        );
      }

      await Promise.all([
        page.waitForLoadState('networkidle').catch(() => undefined),
        submitButton.click(),
      ]);
      logger.info('Formulario de login submetido, aguardando resposta...');

      const errorLocator = await firstVisible(page, SELECTORS.errorMessage, 4000);
      if (errorLocator) {
        const errorText = (await errorLocator.textContent())?.trim() ?? 'Credenciais invalidas.';
        logger.error(`Falha no login: ${errorText}`);
        return LoginResult.failure(errorText);
      }

      const loggedInLocator = await firstVisible(page, SELECTORS.loggedInIndicator, env.browser.timeoutMs);
      if (!loggedInLocator) {
        throw new AuthenticationError(
          'Nao foi possivel confirmar que o login foi concluido (indicador de dashboard nao encontrado). Ajuste SELECTORS.loggedInIndicator.',
        );
      }

      await this.persistSession();
      logger.info('Login realizado com sucesso.');
      return LoginResult.success();
    } catch (error) {
      logger.error('Erro durante o processo de login.', { error });
      if (error instanceof AuthenticationError) {
        return LoginResult.failure(error.message);
      }
      return LoginResult.failure('Erro inesperado durante o login. Veja logs/error.log para detalhes.');
    } finally {
      await page.close();
    }
  }

  /**
   * Salva o estado da sessao (cookies + localStorage) em disco,
   * permitindo reaproveitar o login em execucoes futuras sem repetir o processo.
   */
  private async persistSession(): Promise<void> {
    const storagePath = env.browser.storageStatePath;
    const dir = path.dirname(storagePath);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    await this.context.storageState({ path: storagePath });
    logger.info(`Sessao salva em: ${storagePath}`);
  }
}
