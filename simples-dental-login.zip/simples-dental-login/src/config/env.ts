import { config as loadDotEnv } from 'dotenv';
import path from 'path';

loadDotEnv();

interface AppConfig {
  simplesDental: {
    loginUrl: string;
    username: string;
    password: string;
  };
  browser: {
    type: 'chromium' | 'firefox' | 'webkit';
    headless: boolean;
    slowMo: number;
    timeoutMs: number;
    storageStatePath: string;
  };
  log: {
    level: string;
    dir: string;
  };
}

function requireEnv(key: string): string {
  const value = process.env[key];
  if (!value || value.trim().length === 0) {
    throw new Error(
      `Variavel de ambiente obrigatoria ausente: "${key}". Verifique o arquivo .env (use .env.example como referencia).`,
    );
  }
  return value;
}

function parseBrowserType(value: string | undefined): 'chromium' | 'firefox' | 'webkit' {
  const allowed = ['chromium', 'firefox', 'webkit'];
  const normalized = (value ?? 'chromium').toLowerCase();
  if (!allowed.includes(normalized)) {
    throw new Error(`BROWSER_TYPE invalido: "${value}". Use um dos valores: ${allowed.join(', ')}.`);
  }
  return normalized as 'chromium' | 'firefox' | 'webkit';
}

export const env: AppConfig = {
  simplesDental: {
    loginUrl: process.env.SIMPLES_DENTAL_LOGIN_URL ?? 'https://app.simplesdental.com/',
    username: requireEnv('SIMPLES_DENTAL_USERNAME'),
    password: requireEnv('SIMPLES_DENTAL_PASSWORD'),
  },
  browser: {
    type: parseBrowserType(process.env.BROWSER_TYPE),
    headless: (process.env.BROWSER_HEADLESS ?? 'true').toLowerCase() !== 'false',
    slowMo: Number(process.env.BROWSER_SLOW_MO ?? 0),
    timeoutMs: Number(process.env.BROWSER_TIMEOUT_MS ?? 30000),
    storageStatePath: path.resolve(process.cwd(), process.env.STORAGE_STATE_PATH ?? './storage/session.json'),
  },
  log: {
    level: process.env.LOG_LEVEL ?? 'info',
    dir: path.resolve(process.cwd(), process.env.LOG_DIR ?? './logs'),
  },
};
